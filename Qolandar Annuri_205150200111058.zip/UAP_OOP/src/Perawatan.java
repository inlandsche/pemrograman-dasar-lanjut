public interface Perawatan {
    public void treatment();
}
