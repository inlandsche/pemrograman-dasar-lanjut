package program.generic.data;

public class ArrayCounter {

    public static <T> int count(T[] array){
        return array.length;
    }
}
